package com.wave.player.player

import android.app.Application
import android.content.ComponentName
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.wave.player.data.ArtLoader
import com.wave.player.data.MusicRepository
import com.wave.player.data.Song
import com.wave.player.lyrics.LyricsRepository
import com.wave.player.lyrics.LyricsState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val musicRepo = MusicRepository(app)
    private val lyricsRepo = LyricsRepository(app)
    private var controller: MediaController? = null

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _scanned = MutableStateFlow(false)
    val scanned: StateFlow<Boolean> = _scanned.asStateFlow()

    private val _current = MutableStateFlow<Song?>(null)
    val current: StateFlow<Song?> = _current.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _positionMs = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _positionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _shuffle = MutableStateFlow(false)
    val shuffle: StateFlow<Boolean> = _shuffle.asStateFlow()

    private val _repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val repeat: StateFlow<Int> = _repeat.asStateFlow()

    private val _lyrics = MutableStateFlow<LyricsState>(LyricsState.Idle)
    val lyrics: StateFlow<LyricsState> = _lyrics.asStateFlow()

    private val _art = MutableStateFlow<Bitmap?>(null)
    val art: StateFlow<Bitmap?> = _art.asStateFlow()

    private var lyricsJob: Job? = null
    private var artJob: Job? = null
    private var loadingLibrary = false

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _isPlaying.value = isPlaying
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            onItemChanged(mediaItem)
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val d = controller?.duration ?: 0L
            if (d > 0L) _durationMs.value = d
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            _shuffle.value = shuffleModeEnabled
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            _repeat.value = repeatMode
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int,
        ) {
            _positionMs.value = newPosition.positionMs
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener(
            {
                try {
                    val c = future.get()
                    controller = c
                    c.addListener(listener)
                    _isPlaying.value = c.isPlaying
                    _shuffle.value = c.shuffleModeEnabled
                    _repeat.value = c.repeatMode
                    onItemChanged(c.currentMediaItem)
                    _positionMs.value = c.currentPosition
                } catch (e: Exception) {
                    // Service could not be reached; playback controls stay inactive.
                }
            },
            ContextCompat.getMainExecutor(app),
        )

        // Smooth position updates so the lyrics follow the music closely.
        viewModelScope.launch {
            while (true) {
                val c = controller
                if (c != null && c.isPlaying) {
                    _positionMs.value = c.currentPosition
                }
                delay(33)
            }
        }
    }

    // ---- Library ----

    fun loadLibrary() {
        if (loadingLibrary || _scanned.value) return
        loadingLibrary = true
        viewModelScope.launch {
            _songs.value = musicRepo.loadSongs()
            _scanned.value = true
            loadingLibrary = false
            controller?.let { c ->
                if (c.mediaItemCount > 0) {
                    onItemChanged(c.currentMediaItem)
                    _positionMs.value = c.currentPosition
                }
            }
        }
    }

    // ---- Playback controls ----

    fun play(song: Song) {
        val c = controller ?: return
        if (_current.value?.id == song.id && c.mediaItemCount > 0) {
            c.play()
            return
        }
        val list = _songs.value
        val index = list.indexOfFirst { it.id == song.id }
        if (index < 0) return
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        _positionMs.value = ms
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    // ---- Lyrics ----

    fun importLyrics(uri: Uri) {
        val song = _current.value ?: return
        viewModelScope.launch {
            _lyrics.value = LyricsState.Loading
            _lyrics.value = lyricsRepo.importFile(song, uri)
        }
    }

    fun retryLyrics() {
        val song = _current.value ?: return
        lyricsJob?.cancel()
        lyricsJob = viewModelScope.launch {
            _lyrics.value = LyricsState.Loading
            _lyrics.value = lyricsRepo.retry(song)
        }
    }

    // ---- Internals ----

    private fun onItemChanged(item: MediaItem?) {
        val song = item?.mediaId?.toLongOrNull()?.let { id -> _songs.value.firstOrNull { it.id == id } }

        if (song != null && song.id == _current.value?.id && _lyrics.value !is LyricsState.Idle) {
            _positionMs.value = 0L
            return
        }

        _current.value = song
        _positionMs.value = 0L
        lyricsJob?.cancel()
        artJob?.cancel()

        if (song == null) {
            _lyrics.value = LyricsState.Idle
            _art.value = null
            return
        }

        _durationMs.value = song.durationMs
        _lyrics.value = LyricsState.Loading
        _art.value = null

        artJob = viewModelScope.launch {
            _art.value = ArtLoader.load(getApplication(), song, 700)
        }
        lyricsJob = viewModelScope.launch {
            _lyrics.value = lyricsRepo.load(song)
        }
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}

private fun Song.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(albumArtUri)
                .build()
        )
        .build()
