package com.wave.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Loads album art for a song (embedded art or the album's cover) with a small in-memory cache. */
object ArtLoader {

    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    suspend fun load(context: Context, song: Song, px: Int): Bitmap? = withContext(Dispatchers.IO) {
        val size = px.coerceAtLeast(64)
        val key = "${song.id}_$size"
        cache.get(key)?.let { return@withContext it }

        val bitmap: Bitmap? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.loadThumbnail(song.uri, Size(size, size), null)
            } else {
                context.contentResolver.openInputStream(song.albumArtUri)?.use {
                    BitmapFactory.decodeStream(it)
                }
            }
        } catch (e: Exception) {
            null
        }

        if (bitmap != null) cache.put(key, bitmap)
        bitmap
    }
}
