package com.wave.player.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WaveColors = darkColorScheme(
    primary = Color(0xFFFF2D55),
    onPrimary = Color.White,
    background = Color(0xFF0B0B0F),
    onBackground = Color.White,
    surface = Color(0xFF15151B),
    onSurface = Color.White,
)

@Composable
fun WaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = WaveColors, content = content)
}
