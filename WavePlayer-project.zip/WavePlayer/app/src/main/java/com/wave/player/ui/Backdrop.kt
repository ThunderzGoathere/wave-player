package com.wave.player.ui

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.palette.graphics.Palette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

val DefaultBackdrop: List<Color> = listOf(
    Color(0xFF3A1C71),
    Color(0xFFD76D77),
    Color(0xFFFFAF7B),
    Color(0xFF1E3C72),
)

/** Picks four vivid colors from the album art to paint the moving background. */
fun extractBackdropColors(bitmap: Bitmap?): List<Color> {
    if (bitmap == null) return DefaultBackdrop
    return try {
        // Palette needs a software bitmap.
        val source = if (bitmap.config == Bitmap.Config.HARDWARE) {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            bitmap
        }
        val palette = Palette.from(source).resizeBitmapArea(100 * 100).generate()
        val picked = listOf(
            palette.getVibrantColor(0),
            palette.getDarkVibrantColor(0),
            palette.getMutedColor(0),
            palette.getDominantColor(0),
        ).filter { it != 0 }.map { Color(it) }
        if (picked.isEmpty()) DefaultBackdrop else List(4) { picked[it % picked.size] }
    } catch (e: Exception) {
        DefaultBackdrop
    }
}

/** Slowly drifting, blurred color blobs, in the style of Apple Music's Now Playing screen. */
@Composable
fun AnimatedBackdrop(colors: List<Color>, modifier: Modifier = Modifier) {
    val c0 by animateColorAsState(targetValue = colors[0], animationSpec = tween(1000), label = "c0")
    val c1 by animateColorAsState(targetValue = colors[1], animationSpec = tween(1000), label = "c1")
    val c2 by animateColorAsState(targetValue = colors[2], animationSpec = tween(1000), label = "c2")
    val c3 by animateColorAsState(targetValue = colors[3], animationSpec = tween(1000), label = "c3")

    val transition = rememberInfiniteTransition(label = "backdrop")
    val tau = (2 * PI).toFloat()
    val a by transition.animateFloat(
        initialValue = 0f,
        targetValue = tau,
        animationSpec = infiniteRepeatable(tween(28000, easing = LinearEasing)),
        label = "a",
    )
    val b by transition.animateFloat(
        initialValue = 0f,
        targetValue = tau,
        animationSpec = infiniteRepeatable(tween(41000, easing = LinearEasing)),
        label = "b",
    )

    Canvas(modifier.fillMaxSize().background(Color(0xFF0B0B0F))) {
        val w = size.width
        val h = size.height
        val radius = max(w, h) * 0.8f

        fun blob(color: Color, cx: Float, cy: Float) {
            val center = Offset(cx, cy)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color.copy(alpha = 0.9f), Color.Transparent),
                    center = center,
                    radius = radius,
                ),
                radius = radius,
                center = center,
            )
        }

        blob(c0, w * (0.25f + 0.25f * cos(a)), h * (0.20f + 0.15f * sin(b)))
        blob(c1, w * (0.80f + 0.20f * sin(a)), h * (0.35f + 0.20f * cos(b)))
        blob(c2, w * (0.30f + 0.25f * sin(b)), h * (0.75f + 0.15f * cos(a)))
        blob(c3, w * (0.85f + 0.15f * cos(b)), h * (0.90f + 0.10f * sin(a)))

        // Keep text readable on bright album colors.
        drawRect(Color.Black.copy(alpha = 0.28f))
    }
}
