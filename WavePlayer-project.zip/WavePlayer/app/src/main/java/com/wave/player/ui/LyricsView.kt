package com.wave.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wave.player.lyrics.LyricLine
import com.wave.player.lyrics.LyricsState
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.min

@Composable
fun LyricsPanel(
    state: LyricsState,
    position: State<Long>,
    onSeek: (Long) -> Unit,
    onRetry: () -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier) {
        when (state) {
            is LyricsState.Synced -> WaveLyrics(
                lines = state.lines,
                position = position,
                onSeek = onSeek,
                modifier = Modifier.fillMaxSize(),
            )
            is LyricsState.Plain -> PlainLyrics(state.text)
            LyricsState.Loading -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp)
                Spacer(Modifier.height(16.dp))
                Text("Finding lyrics…", color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
            }
            LyricsState.Idle, LyricsState.NotFound -> NoLyrics(onRetry, onImport)
        }
    }
}

@Composable
private fun NoLyrics(onRetry: () -> Unit, onImport: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "No synced lyrics found",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Lyrics are looked up online when you're connected. You can also import an .lrc file for this song.",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        Row {
            Pill("Try again", selected = false, onClick = onRetry)
            Spacer(Modifier.width(12.dp))
            Pill("Import .lrc", selected = true, onClick = onImport)
        }
    }
}

@Composable
private fun PlainLyrics(text: String) {
    Text(
        text = text,
        color = Color.White.copy(alpha = 0.92f),
        fontSize = 22.sp,
        lineHeight = 32.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
    )
}

private fun activeLineIndex(lines: List<LyricLine>, positionMs: Long): Int {
    val p = positionMs + 120 // show a line a hair before it is sung
    var lo = 0
    var hi = lines.size - 1
    var answer = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= p) {
            answer = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return answer
}

/**
 * Apple Music style lyrics: the current line sits near the top third, large and bright.
 * Other lines are dimmed and blurred by distance. When the line changes, every line glides
 * to its new place with a small delay that grows with distance, which creates the "wave".
 */
@Composable
private fun WaveLyrics(
    lines: List<LyricLine>,
    position: State<Long>,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val gapPx = with(LocalDensity.current) { 26.dp.toPx() }
    val activeIndex by remember(lines) {
        derivedStateOf { activeLineIndex(lines, position.value) }
    }
    val heights = remember(lines) { mutableStateMapOf<Int, Int>() }
    var viewportHeight by remember { mutableIntStateOf(0) }
    var ready by remember(lines) { mutableStateOf(false) }

    val measured = heights.size == lines.size && viewportHeight > 0
    LaunchedEffect(measured, lines) {
        if (measured) {
            // Let the first measured layout settle before animations start.
            delay(32)
            ready = true
        }
    }

    val focus = activeIndex.coerceAtLeast(0)
    val tops = FloatArray(lines.size)
    var acc = 0f
    for (i in lines.indices) {
        tops[i] = acc
        acc += (heights[i] ?: 0) + gapPx
    }
    val anchor = viewportHeight * 0.30f

    Box(
        modifier
            .onSizeChanged { viewportHeight = it.height }
            .clipToBounds()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.08f to Color.Black,
                        0.88f to Color.Black,
                        1f to Color.Transparent,
                    ),
                    blendMode = BlendMode.DstIn,
                )
            }
    ) {
        lines.forEachIndexed { index, line ->
            key(index) {
                WaveLine(
                    line = line,
                    index = index,
                    focus = focus,
                    activeIndex = activeIndex,
                    targetY = anchor + tops[index] - tops[focus],
                    ready = ready,
                    onHeight = { h -> if (heights[index] != h) heights[index] = h },
                    onClick = { onSeek(line.timeMs) },
                )
            }
        }
    }
}

@Composable
private fun WaveLine(
    line: LyricLine,
    index: Int,
    focus: Int,
    activeIndex: Int,
    targetY: Float,
    ready: Boolean,
    onHeight: (Int) -> Unit,
    onClick: () -> Unit,
) {
    val offsetY = remember { Animatable(targetY) }

    LaunchedEffect(targetY, ready) {
        val distance = abs(index - focus)
        if (!ready || distance > 8) {
            offsetY.snapTo(targetY)
        } else {
            // Lines below the current one follow a little later, like a wave.
            if (index >= focus) delay(min(distance, 6) * 50L)
            offsetY.animateTo(targetY, spring(dampingRatio = 0.85f, stiffness = 240f))
        }
    }

    val isActive = index == activeIndex
    val distanceFromActive = abs(index - activeIndex)

    val lineScale by animateFloatAsState(
        targetValue = if (isActive) 1f else 0.9f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow),
        label = "lineScale",
    )
    val lineAlpha by animateFloatAsState(
        targetValue = when {
            !ready -> 0f
            isActive -> 1f
            distanceFromActive == 1 -> 0.5f
            distanceFromActive == 2 -> 0.38f
            else -> 0.28f
        },
        animationSpec = tween(400),
        label = "lineAlpha",
    )
    val lineBlur by animateDpAsState(
        targetValue = if (isActive || !ready) 0.dp else (min(distanceFromActive, 4) * 1.5f).dp,
        animationSpec = tween(400),
        label = "lineBlur",
    )

    Box(
        Modifier
            .fillMaxWidth()
            .onSizeChanged { onHeight(it.height) }
            .graphicsLayer {
                translationY = offsetY.value
                scaleX = lineScale
                scaleY = lineScale
                transformOrigin = TransformOrigin(0f, 0.5f)
                alpha = lineAlpha
            }
            .blur(lineBlur, BlurredEdgeTreatment.Unbounded)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            )
            .padding(end = 20.dp)
    ) {
        Text(
            text = line.text.ifBlank { "• • •" },
            color = Color.White,
            fontSize = 30.sp,
            lineHeight = 36.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
