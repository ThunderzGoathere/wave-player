package com.wave.player.lyrics

import android.content.Context
import android.net.Uri
import com.wave.player.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/**
 * Finds synced lyrics for a song:
 *  1. a cached or imported .lrc in the app's private storage,
 *  2. otherwise the free LRCLIB service (https://lrclib.net) by title, artist and duration.
 */
class LyricsRepository(private val context: Context) {

    private val dir = File(context.filesDir, "lyrics").apply { mkdirs() }

    private fun cacheFile(song: Song, ext: String) = File(dir, "${song.id}.$ext")

    suspend fun load(song: Song): LyricsState = withContext(Dispatchers.IO) {
        val lrc = cacheFile(song, "lrc")
        if (lrc.exists()) {
            val lines = LrcParser.parse(lrc.readText())
            if (lines.isNotEmpty()) return@withContext LyricsState.Synced(lines)
        }
        val txt = cacheFile(song, "txt")
        if (txt.exists()) return@withContext LyricsState.Plain(txt.readText())

        fetchOnline(song)
    }

    suspend fun retry(song: Song): LyricsState = withContext(Dispatchers.IO) {
        cacheFile(song, "lrc").delete()
        cacheFile(song, "txt").delete()
        fetchOnline(song)
    }

    suspend fun importFile(song: Song, uri: Uri): LyricsState = withContext(Dispatchers.IO) {
        try {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: return@withContext LyricsState.NotFound
            val lines = LrcParser.parse(text)
            if (lines.isNotEmpty()) {
                cacheFile(song, "lrc").writeText(text)
                LyricsState.Synced(lines)
            } else if (text.isNotBlank()) {
                cacheFile(song, "txt").writeText(text)
                LyricsState.Plain(text)
            } else {
                LyricsState.NotFound
            }
        } catch (e: Exception) {
            LyricsState.NotFound
        }
    }

    private fun fetchOnline(song: Song): LyricsState {
        val durSec = (song.durationMs / 1000).toInt()
        val artistKnown = song.artist.isNotBlank() && !song.artist.equals("Unknown artist", ignoreCase = true)
        val artistPart = if (artistKnown) "&artist_name=${enc(song.artist)}" else ""
        val albumPart = if (song.album.isNotBlank()) "&album_name=${enc(song.album)}" else ""

        return try {
            var synced = ""
            var plain = ""

            val direct = httpGet(
                "https://lrclib.net/api/get?track_name=${enc(song.title)}$artistPart$albumPart&duration=$durSec"
            )
            if (direct != null) {
                val o = JSONObject(direct)
                synced = o.str("syncedLyrics")
                plain = o.str("plainLyrics")
            }

            if (synced.isBlank()) {
                val res = httpGet("https://lrclib.net/api/search?track_name=${enc(song.title)}$artistPart")
                if (res != null) {
                    val arr = JSONArray(res)
                    var best: JSONObject? = null
                    var bestDiff = Double.MAX_VALUE
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        if (o.str("syncedLyrics").isBlank()) continue
                        val diff = abs(o.optDouble("duration", 0.0) - durSec)
                        if (diff < bestDiff) {
                            best = o
                            bestDiff = diff
                        }
                    }
                    if (best != null && bestDiff <= 8.0) {
                        synced = best.str("syncedLyrics")
                    }
                }
            }

            when {
                synced.isNotBlank() -> {
                    val lines = LrcParser.parse(synced)
                    if (lines.isNotEmpty()) {
                        cacheFile(song, "lrc").writeText(synced)
                        LyricsState.Synced(lines)
                    } else {
                        LyricsState.NotFound
                    }
                }
                plain.isNotBlank() -> {
                    cacheFile(song, "txt").writeText(plain)
                    LyricsState.Plain(plain)
                }
                else -> LyricsState.NotFound
            }
        } catch (e: Exception) {
            LyricsState.NotFound
        }
    }

    private fun httpGet(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "WavePlayer/1.0 (Android)")
            if (conn.responseCode == 200) {
                conn.inputStream.bufferedReader().use { it.readText() }
            } else {
                null
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // org.json returns the string "null" for JSON nulls, so guard against that.
    private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")
}
