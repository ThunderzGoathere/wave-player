# Wave

A music player for Android with Apple Music style lyrics: the current line is large and bright, the lines around it are dimmed and blurred, and the whole page glides in a wave each time the line changes. The background is a slowly moving gradient taken from the album art.

## Features

- Plays the songs stored on your phone (MP3, FLAC, M4A, and so on)
- Background playback with lock screen and notification controls
- Synced lyrics, looked up automatically from the free [LRCLIB](https://lrclib.net) service when you are online
- Import your own `.lrc` lyrics file for any song (button on the player screen)
- Tap any lyric line to jump to that moment
- Library search, shuffle, repeat, seek bar, mini player

## Get the APK (no Android Studio needed)

1. Create a free account at github.com and make a new empty repository.
2. Upload everything from this folder into it, including the hidden `.github` folder (drag the folder contents onto the "uploading an existing file" page).
3. Open the **Actions** tab, choose **Build APK**, and wait about 5 minutes for the green check. If it didn't start by itself, click **Run workflow**.
4. Open the finished run and download **Wave-debug-apk** from the Artifacts section. Unzip it to get `app-debug.apk`.
5. Send the APK to your phone, tap it, and allow "install unknown apps" when asked.

## Or build it with Android Studio

1. Install Android Studio and choose **Open** on this folder.
2. Let Gradle sync finish.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio shows a link to the finished file.

From a terminal: `./gradlew assembleDebug`, and the APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Using the app

1. On first launch, allow access to music (and notifications, so the player controls show).
2. Tap a song. The player opens with lyrics on.
3. If no lyrics appear, tap **Try again**, or **Import .lrc** to pick a lyrics file from your phone.
4. Tap the **Lyrics** pill to switch to the big album art view.

## Notes

- Lyrics matching uses the song title, artist and length from the file's tags. Songs with missing or wrong tags may not match.
- This is a debug build signed with a debug key. That's fine for your own phone. For the Play Store you would need a release key.
